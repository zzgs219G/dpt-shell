# phase1-性能优化方案.zip 归档说明

打包日期：2026-10-11。Phase 1 已全部完成并发布（v1.1.0），方案三件套与
崩溃日志原件归档于此，docs/ 顶层不再保留散文件。

内容清单（文件名与内容均为当时原貌，未做任何改动）：
- phase1-perf-plan.md  Phase 1 性能优化方案（曾是唯一执行依据）
- phase1-design.md      Phase 1 终态设计说明（as-built）
- phase1-test.md        Phase 1 集成验收报告（Task 1.6）
- crash.log             v1.0.8 启动 SIGSEGV 崩溃日志原件（2026-10-07，
  ndk-stack 已符号化；原先被 .gitignore 的 *.log 排除在库外，clone 拿不到，
  现随本包入库）

引用约定：仓库活文档（AGENTS.md / 项目流程.md / 进度与交接.md）中凡出现
"phase1-*.md §N"的引用，均指本包内对应文件的 §N，解压后节号不变、引用仍有效。
